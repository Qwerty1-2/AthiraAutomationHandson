package OnetoMany.model;

public class Customer {

}
