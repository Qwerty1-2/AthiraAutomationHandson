package OnetoMany.repository;

public interface CustomerRepository {

}
