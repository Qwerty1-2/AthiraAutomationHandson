package com.spring.demo_resttemplate_15102024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoResttemplate15102024Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoResttemplate15102024Application.class, args);
	}

}
