package com.spring.demo_resttemplate_15102024;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

//import static java.lang.System.*;
@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplate15102024ApplicationTests {
@Autowired
private MockMvc mockMvc;//send dummy request to rest api with url ,http methods
	@Test
	void testgetTicket() throws Exception {
		mockMvc.perform(get("/redbus/8"))//sending get request with url
		.andExpect(status().isOk()) //checking response http status code
		.andExpect(content().contentType(MediaType.APPLICATION_JSON))//checking repsoncse content type
		.andExpect(jsonPath("$.fromplace").value("pqrrrs"))
		.andExpect(jsonPath("$.toplace").value("mnop"));

	}
		
	@Test
	void testBookTicket() throws Exception {
		mockMvc.perform(post("/redbus").contentType(MediaType.APPLICATION_JSON)
		.content(
				"{\"username\":\"user456\","
				+"\"fromplace\":\"tuvw\","
			    +"\"toplace\":\"klmn\","
			    +"\"email\":\"98562@gmail.com\","
			    +"\"price\":9876.5}"))

		.andExpect(status().isCreated())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON))
		.andExpect(jsonPath("$.username").value("user456"));
	}
	
	@Test
	void testUpdateTicket() throws Exception{
		mockMvc.perform(put("/redbus/27").contentType(MediaType.APPLICATION_JSON)
				.content(
						"{\"username\":\"user456\","
						+"\"fromplace\":\"jjjj\","
					    +"\"toplace\":\"kkkk\","
					    +"\"email\":\"98562@gmail.com\","
					    +"\"price\":9876.5}"))	
		.andExpect(status().isCreated());
	}
	
	@Test
	void cancelTicket() throws Exception {
		mockMvc.perform(delete("/redbus/27"))
		.andExpect(status().isOk());
	}
	}


