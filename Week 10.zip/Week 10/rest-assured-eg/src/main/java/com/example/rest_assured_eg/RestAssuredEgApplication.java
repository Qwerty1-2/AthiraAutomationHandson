package com.example.rest_assured_eg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAssuredEgApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestAssuredEgApplication.class, args);
	}

}
