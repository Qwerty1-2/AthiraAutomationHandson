package com.example.demo_rest_18092024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRest18092024Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoRest18092024Application.class, args);
	}

}
