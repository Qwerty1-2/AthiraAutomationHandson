package com.example.demo_rest_18092024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRest18092024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
