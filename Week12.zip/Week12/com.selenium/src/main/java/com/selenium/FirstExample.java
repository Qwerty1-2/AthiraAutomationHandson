package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Selenium to automate tesing of webpage
public class FirstExample {
	
	public static void main(String args[]) throws InterruptedException {
		
// To Set Chrome Driver Path
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");
//To create an instance of chrome driver
		WebDriver driver=new ChromeDriver();
		
//send get request for sample web page
		driver.get("http://www.example.com");
		
//perform some operation on above loaded webpage(Retrieve title of webpage)
		String title=driver.getTitle();
		
		System.out.println("Page title is :"+title);
		Thread.sleep(3000);
		driver.quit();
	}

}
