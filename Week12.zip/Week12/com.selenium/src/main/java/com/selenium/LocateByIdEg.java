package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByIdEg {
	public static void main(String args[]) throws InterruptedException {

//To set Driver Path 
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");

//To create driver instance
		WebDriver driver=new ChromeDriver();
  
//Load webpage under test
		driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByIdEg.html");//to get local file
//Locate username element by id
		WebElement usernameField=driver.findElement(By.id("username"));
//set value/text to username field		
		usernameField.sendKeys("myusername");
		Thread.sleep(5000);
		
		
////To locate password element
//	WebElement passwordField=driver.findElement(By.id("password"));		
////To send value to password field
//	passwordField.sendKeys("mypassword");
//	Thread.sleep(3000);

	driver.quit();

	}

}
