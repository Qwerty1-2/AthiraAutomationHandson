package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByIdEg2 {
	public static void main(String args[]) throws InterruptedException {
		//To set Chrome Driver Path 
				System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");

		//To create WebDriver instance
				WebDriver driver=new ChromeDriver();
				
		//Load WebPage
				driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByIdEg2.html");
	   
	    //Locate Button Element By Id
				WebElement tbuttonfield=driver.findElement(By.id("testButton"));
				Thread.sleep(3000);
	    //Click Button
				tbuttonfield.click();
				Thread.sleep(2000);
		//Locate Message Element
				WebElement messageField=driver.findElement(By.id("message"));
		//get text in message element
				String umessage=messageField.getText();
		//Display above text
				System.out.println(" Updated Message is "+ umessage);
				Thread.sleep(10000);
			driver.quit();
		  	}

}
