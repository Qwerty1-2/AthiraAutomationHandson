package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByNameEg {

	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByNameEg.html");
//Locate element by name
		WebElement usernameField=driver.findElement(By.name("username"));
		Thread.sleep(3000);

//set some text to element		
		usernameField.sendKeys("myusername");
		Thread.sleep(3000);
//Locate element by name
		WebElement passwordField=driver.findElement(By.name("password"));
		Thread.sleep(3000);

//Locate element by name
		passwordField.sendKeys("mypassword");
		Thread.sleep(3000);
//Locate element by name
				WebElement buttonField=driver.findElement(By.name("loginBtn"));
				Thread.sleep(3000);

//Locate element by name
				buttonField.click();
				Thread.sleep(3000);
        driver.quit();
	}
}
