package com.selenium;

public class LocateByNameEg2 {
//Set driver Property
	
//Create DriverInstance
	
//Load Webpage
	
//wait until webpage is loaded successfully
//Locate username
	
//enter text in unsername field
	
//locate age
	
//enter age
	
//locate button
	
//Click Button

//Wait for message to be visible
	
//get updated message text
	
}
