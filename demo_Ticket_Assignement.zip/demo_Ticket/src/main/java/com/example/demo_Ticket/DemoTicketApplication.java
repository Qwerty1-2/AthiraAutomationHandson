package com.example.demo_Ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTicketApplication.class, args);
	}

}
