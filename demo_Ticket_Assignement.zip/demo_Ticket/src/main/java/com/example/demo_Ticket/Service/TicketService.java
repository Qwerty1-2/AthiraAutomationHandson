package com.example.demo_Ticket.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo_Ticket.model.Ticket;
import com.example.demo_Ticket.repository.TicketRepository;

@Service
public class TicketService {
@Autowired
TicketRepository TRepo;


//Get TicketDetails

public Ticket getTicketDetails_service(Integer ticketid) {
	 Optional<Ticket> Iticket= TRepo.findById(ticketid);
	 return Iticket.get();
}

public List<Ticket> getTicketBasedonFromplaceToplace_service(String fromplace,String toplace) {
return TRepo.findByFromplaceOrToplace(fromplace,toplace);

}

/*public float getAveragePrice(String fromplace) {
	List<Ticket> lticket = TRepo.met(fromplace);
	float avg_price = 0;
	for(Ticket t:lticket) {
		avg_price += t.getPrice();
	}
	
	avg_price = avg_price/lticket.size();

	lticket.stream().map(Ticket::getPrice).reduce((total, price)-> total + price

	return avg_price;
}
	 */
public List<Ticket> getEconomyTickets(String fromplace, String toplace, float price){
	return TRepo.findByFromplaceAndToplaceAndPriceLessThan(fromplace, toplace, price);
}
public Ticket bookTicket_service(Ticket ticket) {
	return TRepo.save(ticket);
}

//Update Ticket

public Ticket updateTicket_service(int tid,Ticket ticket) {
 Ticket eticket =TRepo.findById(tid).get();
 eticket.setFromplace(ticket.getFromplace());
 eticket.setToplace(ticket.getToplace());
 eticket.setPrice(ticket.getPrice());
return TRepo.save(eticket);
}


//Delete Ticket

public Ticket cancelTicketRepo(int ticketid) {
	Ticket ticket = TRepo.findById(ticketid).get();
	TRepo.deleteById(ticketid);
	return ticket;
}
}
