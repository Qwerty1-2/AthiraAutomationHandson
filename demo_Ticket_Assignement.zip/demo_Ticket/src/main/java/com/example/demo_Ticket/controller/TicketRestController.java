package com.example.demo_Ticket.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo_Ticket.Service.TicketService;
import com.example.demo_Ticket.exception.InvalidTicketIDException;
import com.example.demo_Ticket.model.Ticket;
import com.springbootDBexample.exception.InvalidPlaceNameException;

@RestController
@RequestMapping("/ticket")
public class TicketRestController {
@Autowired
TicketService Tservice;
//Dependency Injection

//Get Ticket Details based on ID(\ticket\<ticketid>)
@GetMapping("/{id}")
ResponseEntity<Ticket> getTicketDetails(@PathVariable Integer id) {
/* @PathVariable annotation is used to retrieve data from the URL path. By defining placeholders in the request mapping URL, you can bind those placeholders to method parameters annotated with @PathVariable. This allows you to access dynamic values from the URL and use them in your code. @PathVariable annotation is used to extract the userId from the URL path. The {userId} placeholder is defined in the @GetMapping annotation’s URL mapping. The value of the {userId} placeholder will be extracted and passed as the userId method parameter. When a request is made to /users/123, the value 123 will be passed to the getUserDetails method as the userId parameter. You can then use this ID to fetch the user details from a database or any other data source..*/
    Ticket ticket=Tservice.getTicketDetails_service(id);
    if(ticket==null) {
    	throw new InvalidTicketIDException("No such Ticket Exists");
    }
   return new ResponseEntity<Ticket>(ticket,HttpStatus.OK);
}

//GET /ticket/fromto/{fromplace}/{toplace}
@GetMapping("/fromto/{fromplace}/{toplace}")
 ResponseEntity<List<Ticket>>getTicketBasedOnFromplaceToplace(@PathVariable String fromplace,@PathVariable String toplace){
	List<Ticket> Iticket=Tservice.getTicketBasedonFromplaceToplace_service(fromplace,toplace);
	return new ResponseEntity<List<Ticket>>(Iticket,HttpStatus.OK);
}

//@GetMapping("/avgprice/{fromplace}")
//ResponseEntity<Float> getAveragePrice(@PathVariable String fromplace){
//	float avg = Tservice.getAveragePrice(fromplace);
//	return new ResponseEntity<Float>(avg, HttpStatus.OK);
//}

// GET /ticket/fromto/{fromplace}/{toplace}/{maxprice}
	@GetMapping("/economy/{fromplace}/{toplace}/{maxprice}")
	ResponseEntity<List<Ticket>> getEconomyTickets(@PathVariable String fromplace, @PathVariable String toplace, @PathVariable float maxprice ) {
		List<Ticket> lticket = Tservice.getEconomyTickets(fromplace, toplace, maxprice);
		return new ResponseEntity<List<Ticket>>(lticket, HttpStatus.OK);
	}


//To book Ticket(/ticket/book)
@PostMapping("/book")
   ResponseEntity<Ticket> bookTicket(@RequestBody Ticket ticket,@RequestHeader(value="x-custom-hdr")String customhdr ) {
	System.out.println("Custom Http header values is" + customhdr);
if(ticket.getToplace()==null|| ticket.getFromplace()==null) {
	throw new InvalidPlaceNameException("Place Empty or null or doesnt Exist");
}
	
	ticket=Tservice.bookTicket_service(ticket);
//	HttpHeader hearders=new HttpHeaders();
//	headers.add("x-response-hdr", "responsehdr");
	return new ResponseEntity<Ticket>(ticket,HttpStatus.CREATED);
}


//PUT /ticket/update
@PutMapping("/update/{tid}")
	ResponseEntity<Ticket> updateTicket(@PathVariable("tid") Integer tid,@RequestBody Ticket ticket){
		 ticket=Tservice.updateTicket_service(tid,ticket);
		return new ResponseEntity<Ticket>(ticket,HttpStatus.CREATED);
	}



//DELETE /ticket/<ticketid>
@DeleteMapping("/cancel")
ResponseEntity<Integer> cancel(@PathVariable("tid") Integer ticketid) {
	Ticket ticket = Tservice.cancelTicketRepo(ticketid);
	if (ticket == null) {
		throw new InvalidTicketIDException("No such ticket  exists");
	}
	return new ResponseEntity<Integer>(ticketid, HttpStatus.OK);
}
}






