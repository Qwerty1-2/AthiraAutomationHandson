package com.example.demo_Ticket.exception;

public class InvalidPlaceNameException extends RuntimeException{

	public InvalidPlaceNameException(String message) {
		
	super(message);
}
}