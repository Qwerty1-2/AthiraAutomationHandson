package com.example.demo_Ticket.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class TicketExceptionHandler {
//Whatever returned from this method is given back to client during exception scenario	
	@ExceptionHandler(InvalidTicketIDException.class)
	ResponseEntity<String> met(InvalidTicketIDException exep) {
		return new ResponseEntity<String>(exep.getMessage(),HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(InvalidPlaceNameException.class)
	ResponseEntity<String> met(InvalidPlaceNameException exep){
		return new ResponseEntity(exep.getMessage(),HttpStatus.BAD_REQUEST);
	}

}
