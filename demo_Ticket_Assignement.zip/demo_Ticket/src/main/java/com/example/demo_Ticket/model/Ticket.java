package com.example.demo_Ticket.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//Added Entity annotation for marking ticket class as database entity/Class from which DB Table needs to be created
@Entity
public class Ticket {

//Added @Id annotation indicates that field wil act as the ID/ Primary key for the table
@Id
@GeneratedValue(strategy= GenerationType.IDENTITY)
//@GeneratedValue instructs JPA to manage primary key generation, so you don't have to do it manually
	private int id;
@Column
//JPA will default to using the field name as the column name and infer the column type based on the field type.
	private String username;
@Column
	private String fromplace;
@Column
	private String toplace;
@Column
	private Float price;
	
//Added Constructor from source
	public Ticket(int id, String username, String fromplace, String toplace, Float price) {
		super();
		this.id = id;
		this.username = username;
		this.fromplace = fromplace;
		this.toplace = toplace;
		this.price = price;
	}

//Added Getters and setters from source
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFromplace() {
		return fromplace;
	}
	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}
	public String getToplace() {
		return toplace;
	}
	public void setToplace(String toplace) {
		this.toplace = toplace;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	

}
