package com.example.demo_Ticket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo_Ticket.model.Ticket;


/*@repository annotation is built on the top of the classes that manage the code related to the database. 
The annotation helps to easily retrieve, update, and delete content in the database.by extending JpaRepository we get a bunch of generic CRUD methods into our type that allows saving Accounts, deleting them and so on. Second, this will allow the Spring Data JPA repository infrastructure to scan the classpath for this interface and create a Spring bean for it.
(JPA Repository is an Interface)*/
@Repository
public interface TicketRepository extends JpaRepository<Ticket,Integer> {

/* Get all Tickets with a specific From Place and To Place */
//Derived Query method
	public List<Ticket> findByFromplaceOrToplace(String from_place, String to_place);

	/* Get all Tickets From Place and to Place , Price less than */
	public List<Ticket> findByFromplaceAndToplaceAndPriceLessThan(String from_place, String to_place, float price);

	//public List<Ticket> met(String fromplace);
}
