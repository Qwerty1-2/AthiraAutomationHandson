package com.example.demo_Ticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
